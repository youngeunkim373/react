// import { Fragment } from "react/cjs/react.prodution.min";

function MyJsx002() {
  return (
    // <Fragment>
    <>
      <p>start</p>
      <span>!!!</span>
    </>
    // </Fragment>
  );
}

export default MyJsx002;
