function MyJsx001() {
  return (
    <div>
      <div>Hello</div>
      <div>React</div>
    </div>
  );
}

export default MyJsx001;
